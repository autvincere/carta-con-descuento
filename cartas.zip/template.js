const templateCartas =
     `
               <div id="one" class="card">
               <div class="face face--front">

               </div>

               <div class="face face--back">
                    <h2 id= "lose">lose</h2>
               </div>
          </div>

          <div id="two" class="card">
               <div class="face face--front">

               </div>

               <div class="face face--back">
                    <h2 id= "lose">lose</h2>
               </div>
          </div>

          <div id="three" class="card">
               <div class="face face--front">

               </div>

               <div class="face face--back">
                    <h2 id= "lose">lose</h2>
               </div>
          </div>

          <div id="four" class="card">
               <div class="face face--front">

               </div>

               <div class="face face--back">
                    <h2 id= "lose">lose</h2>
               </div>
          </div>

          <div id="five" class="card">
               <div class="face face--front">

               </div>

               <div class="face face--back">
                    <h2 id= "lose">lose</h2>
               </div>
          </div>

          <div id="six" class="card">
               <div class="face face--front">

               </div>

               <div class="face face--back">
                    <h2 id= "lose">lose</h2>
               </div>
          </div>`;

